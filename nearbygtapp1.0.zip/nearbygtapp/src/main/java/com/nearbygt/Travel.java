package com.nearbygt;

public class Travel {
    private User driver;
    private String startPoint; // Punto de partida (A)
    private String endPoint;   // Destino (B)
    private int availableSeats;
    private double costPerSeat;

    public Travel(User driver, String startPoint, String endPoint, int availableSeats, double costPerSeat) {
        this.driver = driver;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.availableSeats = availableSeats;
        this.costPerSeat = costPerSeat;
    }

    public User getDriver() {
        return driver;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public double getCostPerSeat() {
        return costPerSeat;
    }
}
