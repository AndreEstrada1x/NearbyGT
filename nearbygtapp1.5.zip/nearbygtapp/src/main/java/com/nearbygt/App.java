package com.nearbygt;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
    private List<User> users = new ArrayList<>();
    private List<Travel> travels = new ArrayList<>();
    private User currentUser; // Seguimiento del usuario que ha iniciado sesión

    private Scanner scanner = new Scanner(System.in);

    public App() throws CsvValidationException {
        loadUsersFromCSV("src/main/resources/users.csv");
        loadTravelsFromCSV("src/main/resources/travels.csv"); // Carga el archivo CSV de rutas
    }

    public static void main(String[] args) throws CsvValidationException {
        App app = new App();
        app.userMenu();
    }

    public void userMenu() {
        System.out.println("Bienvenido a NearbyGT");
    
        if (currentUser == null) {
            showMainMenu();
        } else {
            System.out.println("DEBUG: Rol del usuario actual: " + currentUser.getRole());
            System.out.println("DEBUG: Mostrando menú específico para " + currentUser.getUsername());
    
            if (currentUser.getRole().equalsIgnoreCase("driver")) {
                showDriverMenu();
            } else if (currentUser.getRole().equalsIgnoreCase("passenger")) {
                showPassengerMenu();
            }
        }
    }
    
    

    private void showMainMenu() {
        System.out.println("Seleccione una opción:");
        System.out.println("1. Crear una cuenta");
        System.out.println("2. Ingresar a una cuenta existente");
        System.out.print("Opción: ");
        int option = scanner.nextInt();
        scanner.nextLine();

        if (option == 1) {
            createAccount();
        } else if (option == 2) {
            login();
        } else {
            System.out.println("Opción no válida. Intente de nuevo.");
        }
    }

    private void createAccount() {
        System.out.print("Ingrese su nombre: ");
        String username = scanner.nextLine();

        System.out.print("Ingrese un PIN de 4 dígitos para su cuenta: ");
        String pin = scanner.next();

        if (isUserExists(username, pin)) {
            System.out.println("ERROR: Ya existe un usuario con el mismo nombre y PIN. Regresando al menú principal.");
            userMenu();
            return;
        }

        if (!pin.matches("\\d{4}")) {
            System.out.println("ERROR: El PIN debe tener 4 dígitos. Regresando al menú principal.");
            userMenu();
            return;
        }

        System.out.print("¿Es usted conductor o pasajero? (conductor/pasajero): ");
        String role = scanner.next();

        System.out.print("Ingrese su número de teléfono: ");
        String phoneNumber = scanner.next();
        scanner.nextLine();

        System.out.print("Ingrese su ubicación: ");
        String location = scanner.nextLine();

        User currentUser = new User(username, phoneNumber, location, role, pin);
        users.add(currentUser);

        System.out.println("Cuenta creada con éxito. Regresando al menú principal.");
        userMenu();
    }

    // En el método login()
    private void login() {
        System.out.print("Ingrese su nombre de usuario: ");
        String enteredUsername = scanner.nextLine();
        
        System.out.print("Ingrese su PIN de 4 dígitos: ");
        String enteredPin = scanner.nextLine();
    
        if (enteredUsername.equalsIgnoreCase("desarrollador") && enteredPin.equals("4978")) {
            // Acceso al modo desarrollador
            try {
                developerMenu();
            } catch (CsvValidationException e) {
                System.out.println("Error en el modo desarrollador: " + e.getMessage());
            }
        } else {
            User foundUser = findUserByUsernameAndPin(enteredUsername, enteredPin);
    
            if (foundUser != null) {
                System.out.println("Ingreso exitoso como " + foundUser.getRole());
                currentUser = foundUser;
                System.out.println("DEBUG: Rol del usuario después del inicio de sesión: " + currentUser.getRole());
                // Después del inicio de sesión exitoso, muestra el menú principal del usuario
                userMenu();
            } else {
                System.out.println("Nombre de usuario o PIN incorrecto. Ingreso fallido.");
            }
        }
    }   
    
    private void showDriverMenu() {
        System.out.println("Menú de Usuario Conductor");
        System.out.println("1. Agregar una ruta");
        System.out.println("2. Buscar pasajeros");
        System.out.println("3. Cerrar sesión");
        System.out.print("Seleccione una opción: ");
        int userOption = scanner.nextInt();
        scanner.nextLine();

        switch (userOption) {
            case 1:
                addNewTravel(currentUser);
                break;
            case 2:
                findPassengers();
                break;
            case 3:
                currentUser = null;
                System.out.println("Sesión cerrada. Volviendo al menú principal.");
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
        }
    }

    private void showPassengerMenu() {
        System.out.println("Menú de Usuario Pasajero");
        System.out.println("1. Agregar una ruta");
        System.out.println("2. Encontrar rutas compartidas");
        System.out.println("3. Cerrar sesión");
        System.out.print("Seleccione una opción: ");
        int userOption = scanner.nextInt();
        scanner.nextLine();

        switch (userOption) {
            case 1:
                addNewTravel(currentUser);
                break;
            case 2:
                findSharedRides(currentUser);
                break;
            case 3:
                currentUser = null;
                System.out.println("Sesión cerrada. Volviendo al menú principal.");
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
        }
    }

    public void findSharedRides(User currentUser) {
        System.out.print("Ingrese el punto de partida (A): ");
        String startPoint = scanner.nextLine();

        System.out.print("Ingrese el destino (B): ");
        String endPoint = scanner.nextLine();

        List<Travel> matchingTravels = new ArrayList<>();

        for (Travel travel : travels) {
            if (!travel.getDriver().equals(currentUser) && travel.getAvailableSeats() > 0) {
                if (travel.getStartPoint().equalsIgnoreCase(startPoint) && travel.getEndPoint().equalsIgnoreCase(endPoint)) {
                    matchingTravels.add(travel);
                }
            }
        }

        if (matchingTravels.isEmpty()) {
            System.out.println("No se encontraron rutas compartidas similares.");
        } else {
            System.out.println("Rutas compartidas similares encontradas:");
            for (int i = 0; i < matchingTravels.size(); i++) {
                Travel sharedRide = matchingTravels.get(i);
                User driver = sharedRide.getDriver();
                System.out.println((i + 1) + ". Conductor: " + driver.getUsername());
            }

            System.out.print("Seleccione el número de la ruta compartida que le interese: ");
            int choice = scanner.nextInt();
            if (choice >= 1 && choice <= matchingTravels.size()) {
                Travel selectedRide = matchingTravels.get(choice - 1);
                User driver = selectedRide.getDriver();
                System.out.println("Información de contacto del conductor:");
                System.out.println("Nombre: " + driver.getUsername());
                System.out.println("Número de teléfono: " + driver.getPhoneNumber());
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }

    private void findPassengers() {
        System.out.print("Ingrese el punto de partida (A): ");
        String startPoint = scanner.nextLine();
    
        System.out.print("Ingrese el destino (B): ");
        String endPoint = scanner.nextLine();
    
        List<Travel> matchingTravels = new ArrayList<>();
    
        for (Travel travel : travels) {
            if (travel.getDriver() != currentUser && travel.getAvailableSeats() > 0) {
                if (travel.getStartPoint().equalsIgnoreCase(startPoint) && travel.getEndPoint().equalsIgnoreCase(endPoint)) {
                    matchingTravels.add(travel);
                }
            }
        }
    
        if (matchingTravels.isEmpty()) {
            System.out.println("No se encontraron pasajeros para su ruta.");
        } else {
            System.out.println("Pasajeros potenciales para su ruta:");
            for (int i = 0; i < matchingTravels.size(); i++) {
                Travel sharedRide = matchingTravels.get(i);
                User passenger = sharedRide.getDriver();
                System.out.println((i + 1) + ". Pasajero: " + passenger.getUsername());
            }
    
            System.out.print("Seleccione el número del pasajero que le interese: ");
            int choice = scanner.nextInt();
            if (choice >= 1 && choice <= matchingTravels.size()) {
                Travel selectedRide = matchingTravels.get(choice - 1);
                User passenger = selectedRide.getDriver();
                System.out.println("Información de contacto del pasajero:");
                System.out.println("Nombre: " + passenger.getUsername());
                System.out.println("Número de teléfono: " + passenger.getPhoneNumber());
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }    

    private void addNewTravel(User currentUser) {
        System.out.print("Ingrese el punto de partida (A): ");
        String startPoint = scanner.nextLine();

        System.out.print("Ingrese el destino (B): ");
        String endPoint = scanner.nextLine();

        System.out.print("Número de asientos disponibles: ");
        int availableSeats = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Costo por asiento: ");
        double costPerSeat = scanner.nextDouble();
        scanner.nextLine();

        Travel newTravel = new Travel(currentUser, startPoint, endPoint, availableSeats, costPerSeat);
        travels.add(newTravel);

        System.out.println("Ruta agregada con éxito.");
    }

    // Métodos de desarrollador

    public void developerMenu() throws CsvValidationException {
        // Acceso directo al modo desarrollador
        System.out.println("Modo Desarrollador Activado");
        boolean exit = false;
            while (!exit) {
                System.out.println("Menú de Desarrollador");
                System.out.println("1. Crear archivo CSV de usuarios");
                System.out.println("2. Cargar usuarios desde archivo CSV");
                System.out.println("3. Ver usuarios con su información");
                System.out.println("4. Ver usuarios con sus rutas");
                System.out.println("5. Agregar información a un usuario");
                System.out.println("6. Quitar información de un usuario");
                System.out.println("7. Salir");
                System.out.print("Seleccione una opción: ");
    
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume la nueva línea.
    
                switch (choice) {
                    case 1:
                        createCSVFile("src/main/resources/users.csv");
                        break;
                    case 2:
                        loadCSVFile("src/main/resources/users.csv");
                        break;
                    case 3:
                        viewUsersWithInfo();
                        break;
                    case 4:
                        viewUsersWithTravels();
                        break;
                    case 5:
                        addInfoToUser();
                        break;
                    case 6:
                        removeInfoFromUser();
                        break;
                    case 7:
                        exit = true;
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }

            }
        }
    
        private void viewUsersWithInfo() {
            System.out.println("Usuarios y su información:");
            for (User user : users) {
                System.out.println("Nombre de usuario: " + user.getUsername());
                System.out.println("Número de teléfono: " + user.getPhoneNumber());
                System.out.println("Ubicación: " + user.getLocation());
                System.out.println("Rol: " + user.getRole());
                System.out.println("PIN: " + user.getPin());
                System.out.println();
            }
        }
        
        private void viewUsersWithTravels() {
            System.out.println("Usuarios y sus rutas:");
            for (User user : users) {
                System.out.println("Nombre de usuario: " + user.getUsername());
                System.out.println("Rutas:");
                for (Travel travel : travels) {
                    if (travel.getDriver().equals(user)) {
                        System.out.println("Desde " + travel.getStartPoint() + " hasta " + travel.getEndPoint());
                    }
                }
                System.out.println();
            }
        }
        
        private void addInfoToUser() {
            System.out.print("Ingrese el nombre de usuario al que desea agregar información: ");
            String username = scanner.nextLine();
            User user = findUserByUsername(username);
            if (user != null) {
                System.out.print("Ingrese la nueva información para el usuario: ");
                String newInfo = scanner.nextLine();
                user.addInfo(newInfo);
                System.out.println("Información agregada con éxito.");
            } else {
                System.out.println("Usuario no encontrado.");
            }
        }
        
        private void removeInfoFromUser() {
            System.out.print("Ingrese el nombre de usuario al que desea quitar información: ");
            String username = scanner.nextLine();
            User user = findUserByUsername(username);
            if (user != null) {
                System.out.print("Ingrese la información que desea quitar al usuario: ");
                String infoToRemove = scanner.nextLine();
                user.removeInfo(infoToRemove);
                System.out.println("Información eliminada con éxito.");
            } else {
                System.out.println("Usuario no encontrado.");
            }
        }        
    
    
    // Métodos para cargar y guardar datos desde y hacia archivos CSV

    private void createCSVFile(String filename) {
        try {
            FileWriter fileWriter = new FileWriter(filename);
            CSVWriter csvWriter = new CSVWriter(fileWriter);

            String[] headerRecord = {"Username", "PhoneNumber", "Location", "Role", "PIN"};
            csvWriter.writeNext(headerRecord);

            for (User user : users) {
                String[] userRecord = {user.getUsername(), user.getPhoneNumber(), user.getLocation(), user.getRole(), user.getPin()};
                csvWriter.writeNext(userRecord);
            }

            csvWriter.close();
            System.out.println("Archivo CSV de usuarios creado con éxito.");
        } catch (IOException e) {
            System.out.println("Error al crear el archivo CSV de usuarios.");
        }
    }

    public void loadCSVFile(String filename) throws CsvValidationException {
        try {
            CSVReader csvReader = new CSVReader(new FileReader(filename));
            String[] nextRecord;
            boolean firstLine = true;

            while ((nextRecord = csvReader.readNext()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String username = nextRecord[0];
                String phoneNumber = nextRecord[1];
                String location = nextRecord[2];
                String role = nextRecord[3];
                String pin = nextRecord[4];

                User loadedUser = new User(username, phoneNumber, location, role, pin);
                users.add(loadedUser);
            }

            System.out.println("Usuarios cargados desde el archivo CSV.");
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios desde el archivo CSV.");
        }
    }

    public void loadUsersFromCSV(String filename) throws CsvValidationException {
        try {
            CSVReader csvReader = new CSVReader(new FileReader(filename));
            String[] nextRecord;
            boolean firstLine = true;

            while ((nextRecord = csvReader.readNext()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String username = nextRecord[0];
                String phoneNumber = nextRecord[1];
                String location = nextRecord[2];
                String role = nextRecord[3];
                String pin = nextRecord[4];

                User loadedUser = new User(username, phoneNumber, location, role, pin);
                users.add(loadedUser);
            }

            System.out.println("Usuarios cargados desde el archivo CSV.");
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios desde el archivo CSV.");
        }
    }

    public void loadTravelsFromCSV(String filename) throws CsvValidationException {
        try {
            CSVReader csvReader = new CSVReader(new FileReader(filename));
            String[] nextRecord;
            boolean firstLine = true;

            while ((nextRecord = csvReader.readNext()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String driverUsername = nextRecord[0];
                String startPoint = nextRecord[1];
                String endPoint = nextRecord[2];
                int availableSeats = Integer.parseInt(nextRecord[3]);
                double costPerSeat = Double.parseDouble(nextRecord[4]);

                User driver = findUserByUsername(driverUsername);
                if (driver != null) {
                    Travel loadedTravel = new Travel(driver, startPoint, endPoint, availableSeats, costPerSeat);
                    travels.add(loadedTravel);
                }
            }

            System.out.println("Rutas cargadas desde el archivo CSV.");
        } catch (IOException e) {
            System.out.println("Error al cargar rutas desde el archivo CSV.");
        }
    }


    // Métodos de Utilidad

    // Método para encontrar un usuario por nombre de usuario y PIN
    private User findUserByUsernameAndPin(String username, String pin) {
        for (User user : users) {
            if (user.getPin().equals(pin) && user.getUsername().equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }     

    private User findUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }

    private boolean isUserExists(String username, String pin) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username) && user.getPin().equals(pin)) {
                return true;
            }
        }
        return false;
    }


}