package com.nearbygt;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String phoneNumber;
    private String location;
    private String role;
    private String pin;
    private List<Travel> routes; // Lista de rutas asociadas a este usuario

    public User(String username, String phoneNumber, String location, String role, String pin) {
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.location = location;
        this.role = role;
        this.pin = pin;
        this.routes = new ArrayList<>(); // Inicializar la lista de rutas
    }

    private List<String> additionalInfo = new ArrayList<>();

    public void addInfo(String info) {
        additionalInfo.add(info);
    }

    public void removeInfo(String info) {
        additionalInfo.remove(info);
    }

    public void viewInfo() {
        System.out.println("Información adicional del usuario " + username + ":");
        for (String info : additionalInfo) {
            System.out.println(info);
        }
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getLocation() {
        return location;
    }

    public String getRole() {
        return role;
    }

    public String getPin() {
        return pin;
    }

    public List<Travel> getRoutes() {
        return routes;
    }

    public void addRoute(Travel route) {
        routes.add(route);
    }
}
